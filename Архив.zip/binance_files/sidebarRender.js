window.hydarteHandler(React.createElement(window.sidebarUMD.default), document.getElementById('__APP_SIDEBAR'))
